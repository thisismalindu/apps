#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "qevent.h"
#include <QMessageBox>
#include <QFile>
#include <QStringList>
#include <QList>
#include <QClipboard>
#include <QTimer>
#include <QSettings>

QString searchString;
QList<QString> symbols;



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setStyleSheet(QString::fromUtf8("QScrollBar:vertical {"

        "}"
        ));
    ui->setupUi(this);


    QString fileName = qApp->applicationDirPath() + "/symbols.txt";

    //Reads All the symbols
    QFile inputFile(fileName);
    if (inputFile.open(QIODevice::ReadOnly))
    {
       QTextStream in(&inputFile);
       while (!in.atEnd())
       {
          symbols << in.readLine();
       }
       inputFile.close();
    }

    for (int i = 0; i < symbols.size()-2; i+=2) {
        int charCount = symbols[i].size();
        QString str;
        for (int j = 0; j < 50-charCount; j++) {
            str +=" ";
        }
        ui->listWidget->addItem(symbols[i] + str + symbols[i+1]);
    }


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_lineEdit_textEdited(const QString &arg1)
{
    ui->listWidget->clear();
    searchString = ui->lineEdit->text();

    QList<QString> tempSymbols = symbols;

    for (int i = 0; i<tempSymbols.size()-2; i+=2) {
        if(tempSymbols[i].contains(searchString)){

            int charCount = symbols[i].size();
            QString str;
            for (int j = 0; j < 50-charCount; j++) {
                str +=" ";
            }

           ui->listWidget->addItem(tempSymbols[i] + str + tempSymbols[i+1]);
        }
    }
    ui->listWidget->setCurrentRow(0);
}


void MainWindow::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    QClipboard *clipboard = QGuiApplication::clipboard();
    clipboard->setText(item->text().remove(0,50));
    showMinimized();
}


void MainWindow::on_lineEdit_returnPressed()
{
    QClipboard *clipboard = QGuiApplication::clipboard();
    clipboard->setText(ui->listWidget->item(0)->text().remove(0,50));
    showMinimized();

}


void MainWindow::on_listWidget_itemActivated(QListWidgetItem *item)
{
    QClipboard *clipboard = QGuiApplication::clipboard();
    clipboard->setText(item->text().remove(0,50));
    showMinimized();
}

void MainWindow::keyPressEvent(QKeyEvent* event)
{
    if(event->key() == Qt::Key_Escape)
    {
//         QCoreApplication::quit();
         showMinimized();
    }
    else{
        QWidget::keyPressEvent(event);
}
}

void MainWindow::changeEvent(QEvent* e)
{
    switch (e->type())
    {

        case QEvent::WindowStateChange:
            {
                if (this->windowState() & Qt::WindowMinimized)
                {
                     QTimer::singleShot(250, this, SLOT(hide()));

                }

                break;
            }
        default:
            break;
    }

    QMainWindow::changeEvent(e);
}
